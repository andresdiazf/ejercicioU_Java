/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemagestion;

import com.mycompany.sistemagestion.forms.FormularioGestorCliente;

/**
 *
 * @author andres diaz
 */ // basado en el curso de Java  -> www.youtube.com/watch?v=Z8zAKYLZBqc&t=23517s&ab_channel=ATLAcademy%28byLucasMoy%29
public class SistemaGestion{

    public static void main(String[] args) {
        FormularioGestorCliente ventana = new FormularioGestorCliente();
        ventana.show();

    }
}
