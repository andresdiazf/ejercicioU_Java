/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistemagestion.crud_dao;

import com.mycompany.sistemagestion.models.Cliente;
import com.mysql.jdbc.StringUtils;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author andres_diaz
 */ // basado en el curso de Java  -> www.youtube.com/watch?v=Z8zAKYLZBqc&t=23517s&ab_channel=ATLAcademy%28byLucasMoy%29

public class ClienteDao {
    
    public Connection conectar (){
        String baseDeDatos = "registro_clientes";
        String usuario = "root";
        String password = "";
        String host = "localhost";
        String puerto = "3306";
        String driver = "com.mysql.jdbc.Driver";
        String conexionUrl ="jdbc:mysql://" + host + ":" + puerto + "/" + baseDeDatos + "?useSSL=false";
        
        Connection conexion = null;
               
        try {
            Class.forName(driver);
            conexion = DriverManager.getConnection(conexionUrl, usuario, password);
            System.out.println("Conexión exitosa"); 
            
            
        } catch (Exception ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null,ex);
        } 
        return conexion;
    }    
    
    
    @SuppressWarnings("UseSpecificCatch")
    
    public void agregar(Cliente miCliente ) throws ClassNotFoundException{ //  conectar lo uso para agregar valores a la BD en el boton guardar
             
               
        try {
            Connection conexion = conectar();
            String sql = "INSERT INTO `clientes` (`id`, `nombre`, `apellido`, `telefono`, `email`, `No_identificacion`) VALUES (NULL, '"
                    + miCliente.getNombre()+"', '"
                    + miCliente.getApellido() +"', '"
                    + miCliente.getTelefono()+"', '"
                    + miCliente.getEmail()+"', '"
                    + miCliente.getIdentificacion()+"')";
            
            Statement statement = conexion.createStatement();
            statement.execute(sql);
            
        } catch (Exception ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null,ex);
        } 
    }

    public void actualizar(Cliente miCliente ) throws ClassNotFoundException{ // este conectar lo uso para agregar valores a la BD en el boton guardar
             
               
        try {
            Connection conexion = conectar();
            String sql = "UPDATE `clientes` SET `nombre` = '"+ miCliente.getNombre()
                    +"', `apellido` = '" + miCliente.getApellido()
                    +"', `telefono` = '" + miCliente.getTelefono()
                    +"', `email` = '" + miCliente.getEmail()
                    +"', `No_identificacion` = '" + miCliente.getIdentificacion()
                    +"' WHERE `clientes`.`id` = "+ miCliente.getId()+";";

            Statement statement = conexion.createStatement();
            statement.execute(sql);
            
        } catch (Exception ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null,ex);
        } 
    }
    
    
    public List<Cliente> listar() {
        List<Cliente> listado = new ArrayList<>();
                
        try {
            Connection conexion = conectar();            
            String sql = "SELECT * FROM `clientes`";    
            
            Statement statement = conexion.createStatement();
            ResultSet resultado = statement.executeQuery(sql);
            
            while(resultado.next()) { /// es para recorrer cada fila de la BD 
                Cliente miCliente = new Cliente();
                miCliente.setId(resultado.getString("id"));
                miCliente.setIdentificacion(resultado.getString("No_identificacion"));
                miCliente.setNombre(resultado.getString("nombre"));
                miCliente.setApellido(resultado.getString("apellido"));
                miCliente.setEmail(resultado.getString("email"));
                miCliente.setTelefono(resultado.getString("telefono"));
                listado.add(miCliente);
            }
            
        } catch (Exception ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null,ex);
        } 
        
        return listado;
    }
    
    public void eliminar (String id){       
        try {
            Connection conexion = conectar();
            String sql = "DELETE FROM clientes WHERE `clientes`.`id` =" + id;
            
            
            Statement statement = conexion.createStatement();
            statement.execute(sql);
            
        } catch (Exception ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null,ex);
        } 
    }   

    public void guardar(Cliente miCliente) throws ClassNotFoundException {
        if (StringUtils.isEmptyOrWhitespaceOnly(miCliente.getId())){
            agregar(miCliente);
        } else {
            actualizar(miCliente);
        }
    }
}
