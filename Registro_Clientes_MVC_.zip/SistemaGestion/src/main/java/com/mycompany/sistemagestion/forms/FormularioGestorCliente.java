/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.sistemagestion.forms;


import com.mycompany.sistemagestion.models.Cliente; // ok
import com.mycompany.sistemagestion.crud_dao.ClienteDao;// ok
import com.mysql.jdbc.StringUtils;// ok
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;


/**
 *
 * @author andres diaz
 */ // basado en el curso de Java  -> www.youtube.com/watch?v=Z8zAKYLZBqc&t=23517s&ab_channel=ATLAcademy%28byLucasMoy%29

public class FormularioGestorCliente extends javax.swing.JFrame {
    
    private List<Cliente> lista = new ArrayList<>();
    private Component parentComponent;
    private boolean adminLoggedIn = false; // Esta es la variable que rastreará si el administrador ha iniciado sesión correctamente.
 
    
    public FormularioGestorCliente() {
        initComponents();
        registroClientes.setEnabledAt(1, false); // Registro de Clientes -> Cambiar a fALSE para desbloquear
        
        jRegistrarContrasena.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
                jRegistrarContrasena.setText(""); // Esto borra el texto cuando el campo obtiene el foco
            }
        });
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel10 = new javax.swing.JLabel();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        registroClientes = new javax.swing.JTabbedPane();
        pestanaIniciarSesion = new javax.swing.JPanel();
        jListaDeplegableSeleccioneSuCargo = new javax.swing.JComboBox<>();
        jLabelSeleccioneCargo = new javax.swing.JLabel();
        jRegistrarContrasena = new javax.swing.JPasswordField();
        jLabelContrasena = new javax.swing.JLabel();
        jLabelUsuario = new javax.swing.JLabel();
        jTextUsuario = new javax.swing.JTextField();
        btnIniciarSesion = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        pestanaRegistroClientes = new javax.swing.JPanel();
        jLabelNombre = new javax.swing.JLabel();
        jTextIdentificacion = new javax.swing.JTextField();
        jLabelApellido = new javax.swing.JLabel();
        jLabelEmail = new javax.swing.JLabel();
        jTextNombre = new javax.swing.JTextField();
        jTextApellido = new javax.swing.JTextField();
        jLabelTelefono = new javax.swing.JLabel();
        jTextEmail = new javax.swing.JTextField();
        jTextTelefono = new javax.swing.JTextField();
        jLabelNoIdentificacion = new javax.swing.JLabel();
        bntGuardar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JListdeClientes = new javax.swing.JList<>();
        jLabelResumenCliente = new javax.swing.JLabel();
        jBntEditar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jLabelResumenCliente1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabelId = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JButton();

        jLabel10.setText("jLabel10");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("App Clientes Supermarket ");
        setBackground(new java.awt.Color(0, 51, 51));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        registroClientes.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        pestanaIniciarSesion.setBackground(new java.awt.Color(0, 204, 204));
        pestanaIniciarSesion.setName("Iniciar Sesión"); // NOI18N

        jListaDeplegableSeleccioneSuCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Administrativo", "Operativo" }));
        jListaDeplegableSeleccioneSuCargo.setToolTipText("");
        jListaDeplegableSeleccioneSuCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jListaDeplegableSeleccioneSuCargoActionPerformed(evt);
            }
        });

        jLabelSeleccioneCargo.setText("Seleccione su cargo:");

        jRegistrarContrasena.setText("jPasswordField1");
        jRegistrarContrasena.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRegistrarContrasenaActionPerformed(evt);
            }
        });

        jLabelContrasena.setText("Contraseña: (Digitar 1234)");

        jLabelUsuario.setText("Usuario");

        jTextUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextUsuarioActionPerformed(evt);
            }
        });

        btnIniciarSesion.setText("Iniciar");
        btnIniciarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarSesionActionPerformed(evt);
            }
        });

        jTextPane1.setBackground(new java.awt.Color(0, 204, 204));
        jTextPane1.setFont(new java.awt.Font("Segoe UI", 3, 16)); // NOI18N
        jTextPane1.setForeground(new java.awt.Color(255, 255, 255));
        jTextPane1.setText("My SuperMartket es una aplicación en Java donde usted puede consultar los clientes de un supermercado según su cargo");
        jTextPane1.setToolTipText("");
        jScrollPane3.setViewportView(jTextPane1);

        javax.swing.GroupLayout pestanaIniciarSesionLayout = new javax.swing.GroupLayout(pestanaIniciarSesion);
        pestanaIniciarSesion.setLayout(pestanaIniciarSesionLayout);
        pestanaIniciarSesionLayout.setHorizontalGroup(
            pestanaIniciarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pestanaIniciarSesionLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(pestanaIniciarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pestanaIniciarSesionLayout.createSequentialGroup()
                        .addComponent(jLabelUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pestanaIniciarSesionLayout.createSequentialGroup()
                        .addGroup(pestanaIniciarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelSeleccioneCargo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jListaDeplegableSeleccioneSuCargo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jTextUsuario, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pestanaIniciarSesionLayout.createSequentialGroup()
                                .addComponent(jLabelContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jRegistrarContrasena, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pestanaIniciarSesionLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(60, 60, 60))))
            .addGroup(pestanaIniciarSesionLayout.createSequentialGroup()
                .addGap(208, 208, 208)
                .addComponent(btnIniciarSesion)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pestanaIniciarSesionLayout.setVerticalGroup(
            pestanaIniciarSesionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pestanaIniciarSesionLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabelSeleccioneCargo)
                .addGap(18, 18, 18)
                .addComponent(jListaDeplegableSeleccioneSuCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabelUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jTextUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jLabelContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jRegistrarContrasena, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(59, 59, 59)
                .addComponent(btnIniciarSesion)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        registroClientes.addTab("Iniciar Sesión", pestanaIniciarSesion);

        pestanaRegistroClientes.setBackground(new java.awt.Color(204, 204, 0));

        jLabelNombre.setText("Nombre:");

        jTextIdentificacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextIdentificacionActionPerformed(evt);
            }
        });

        jLabelApellido.setText("Apellido:");

        jLabelEmail.setText("Email:");

        jTextNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextNombreActionPerformed(evt);
            }
        });

        jTextApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextApellidoActionPerformed(evt);
            }
        });

        jLabelTelefono.setText("Teléfono:");

        jTextEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextEmailActionPerformed(evt);
            }
        });

        jTextTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextTelefonoActionPerformed(evt);
            }
        });

        jLabelNoIdentificacion.setText("No. Identificación:");

        bntGuardar.setText("Guardar");
        bntGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bntGuardarActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(JListdeClientes);

        jLabelResumenCliente.setText("Resumen de Clientes");
        jLabelResumenCliente.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabelResumenClienteAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jBntEditar.setText("Editar");
        jBntEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBntEditarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jLabelResumenCliente1.setText("Registrar Cliente");
        jLabelResumenCliente1.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                jLabelResumenCliente1AncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        jLabel1.setText("Id:");

        javax.swing.GroupLayout pestanaRegistroClientesLayout = new javax.swing.GroupLayout(pestanaRegistroClientes);
        pestanaRegistroClientes.setLayout(pestanaRegistroClientesLayout);
        pestanaRegistroClientesLayout.setHorizontalGroup(
            pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                .addContainerGap(42, Short.MAX_VALUE)
                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                            .addComponent(jBntEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pestanaRegistroClientesLayout.createSequentialGroup()
                            .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pestanaRegistroClientesLayout.createSequentialGroup()
                                    .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabelTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabelNoIdentificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabelEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabelApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18))
                                .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                                    .addComponent(jLabelId)
                                    .addGap(140, 140, 140)
                                    .addComponent(bntGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabelResumenCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextEmail)
                                    .addComponent(jTextTelefono)
                                    .addComponent(jTextIdentificacion)
                                    .addComponent(jTextApellido)
                                    .addComponent(jTextNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pestanaRegistroClientesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabelResumenCliente1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(157, 157, 157))
        );
        pestanaRegistroClientesLayout.setVerticalGroup(
            pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jLabelResumenCliente1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabelNoIdentificacion))
                    .addComponent(jTextIdentificacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                        .addComponent(jLabelNombre)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelApellido)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelEmail)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelTelefono))
                    .addGroup(pestanaRegistroClientesLayout.createSequentialGroup()
                        .addComponent(jTextNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bntGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabelId)
                    .addComponent(jLabel1))
                .addGap(30, 30, 30)
                .addComponent(jLabelResumenCliente)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 57, Short.MAX_VALUE)
                .addGroup(pestanaRegistroClientesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBntEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );

        registroClientes.addTab("Registro Clientes", pestanaRegistroClientes);

        btnCerrarSesion.setText("Cerrar Sesión");
        btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSesionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(226, 226, 226)
                        .addComponent(btnCerrarSesion))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(registroClientes, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(registroClientes)
                .addGap(18, 18, 18)
                .addComponent(btnCerrarSesion)
                .addGap(16, 16, 16))
        );

        registroClientes.getAccessibleContext().setAccessibleName("");
        registroClientes.getAccessibleContext().setAccessibleDescription("");

        getAccessibleContext().setAccessibleParent(pestanaIniciarSesion);

        pack();
    }// </editor-fold>//GEN-END:initComponents

           
    private void limpiarCajasDeTexto(){
        this.jTextNombre.setText("");
        this.jTextApellido.setText("");
        this.jTextEmail.setText("");
        this.jTextTelefono.setText("");
        this.jTextIdentificacion.setText("");
        this.jRegistrarContrasena.setText("");
        this.jTextUsuario.setText("");
        this.jListaDeplegableSeleccioneSuCargo.setSelectedIndex(0);
        this.jLabelId.setText("");
    }
        
       
    private int indiceEdicion = -1; // Esta es la nueva variable

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
        adminLoggedIn = false; // Marca al administrador como no logueado
        registroClientes.setSelectedIndex(0); 
        registroClientes.setEnabledAt(1, false); // Deshabilita Registro de Clientes
        
        limpiarCajasDeTexto();
       
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        actualizarLista();
    }//GEN-LAST:event_formComponentShown

    private void jLabelResumenCliente1AncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabelResumenCliente1AncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabelResumenCliente1AncestorAdded

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        int indice = this.JListdeClientes.getSelectedIndex();
        Cliente miCliente = lista.get(indice);
        ClienteDao dao = new ClienteDao();
        dao.eliminar(miCliente.getId());
        actualizarLista();
        limpiarCajasDeTexto();
        JOptionPane.showMessageDialog(parentComponent,"Se elimino correctamente " );
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void jBntEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBntEditarActionPerformed
        int indice = this.JListdeClientes.getSelectedIndex();
        Cliente miCliente = lista.get(indice);

        this.jTextNombre.setText(miCliente.getNombre());
        this.jTextApellido.setText(miCliente.getApellido());
        this.jTextEmail.setText(miCliente.getEmail());
        this.jTextTelefono.setText(miCliente.getTelefono());
        this.jTextIdentificacion.setText(miCliente.getIdentificacion());
        this.jLabelId.setText(miCliente.getId());

        JOptionPane.showMessageDialog(parentComponent,"Puede editar el texto " );
    }//GEN-LAST:event_jBntEditarActionPerformed

    private void jLabelResumenClienteAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_jLabelResumenClienteAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_jLabelResumenClienteAncestorAdded

    private void bntGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bntGuardarActionPerformed

        try {
            Cliente miCliente = new Cliente();
            miCliente.setNombre(this.jTextNombre.getText());
            miCliente.setApellido(this.jTextApellido.getText());
            miCliente.setTelefono(this.jTextTelefono.getText());
            miCliente.setEmail(this.jTextEmail.getText());
            miCliente.setIdentificacion(this.jTextIdentificacion.getText());

            if (!StringUtils.isEmptyOrWhitespaceOnly(jLabelId.getText())){
                miCliente.setId(jLabelId.getText());
            }

            ClienteDao dao = new ClienteDao();
            dao.guardar(miCliente);

            actualizarLista();
            JOptionPane.showMessageDialog(parentComponent,"Se guardo correctamente al cliente");
            limpiarCajasDeTexto();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FormularioGestorCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_bntGuardarActionPerformed

    private void jTextTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextTelefonoActionPerformed

    private void jTextEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextEmailActionPerformed

    private void jTextApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextApellidoActionPerformed

    private void jTextNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextNombreActionPerformed

    private void jTextIdentificacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextIdentificacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextIdentificacionActionPerformed

    private void btnIniciarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarSesionActionPerformed
        String selectedRole = jListaDeplegableSeleccioneSuCargo.getSelectedItem().toString();

        if (selectedRole.equals("Administrativo") && jRegistrarContrasena.getText().equals("1234")) {
            adminLoggedIn = true;
            registroClientes.setEnabledAt(1, true); // Habilita la pestaña de registro de clientes
            
            registroClientes.setSelectedIndex(1); // Cambia a la pestaña de registro de clientes

        } else {
            JOptionPane.showMessageDialog(parentComponent,"No esta autorizado para realizar Consultas de Cliente" );
        }
    }//GEN-LAST:event_btnIniciarSesionActionPerformed

    private void jTextUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextUsuarioActionPerformed

    private void jRegistrarContrasenaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRegistrarContrasenaActionPerformed

    }//GEN-LAST:event_jRegistrarContrasenaActionPerformed

    private void jListaDeplegableSeleccioneSuCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jListaDeplegableSeleccioneSuCargoActionPerformed
        JComboBox<String> comboBox = (JComboBox<String>) evt.getSource();
        if (comboBox.getSelectedIndex() == 0) {
            comboBox.setSelectedIndex(-1); // Deselecciona el elemento en blanco
        }
    }//GEN-LAST:event_jListaDeplegableSeleccioneSuCargoActionPerformed

    private void actualizarLista(){
        ClienteDao dao = new ClienteDao();
        lista = dao.listar();
        
        
        DefaultListModel datos = new DefaultListModel();
        for (int i = 0;i< lista.size();i++){
            Cliente miCliente = lista.get(i);
            String nombreCompleto = miCliente.getNombreCompleto();
            String identificacion = miCliente.getIdentificacion();
            String elemento = "\t ID " + identificacion + "\t Nombre: " + nombreCompleto;
            datos.addElement(elemento);        
                }
        this.JListdeClientes.setModel(datos);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormularioGestorCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormularioGestorCliente().setVisible(true);
            }
        });
    
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> JListdeClientes;
    private javax.swing.JButton bntGuardar;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnIniciarSesion;
    private javax.swing.JButton jBntEditar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabelApellido;
    private javax.swing.JLabel jLabelContrasena;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelId;
    private javax.swing.JLabel jLabelNoIdentificacion;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JLabel jLabelResumenCliente;
    private javax.swing.JLabel jLabelResumenCliente1;
    private javax.swing.JLabel jLabelSeleccioneCargo;
    private javax.swing.JLabel jLabelTelefono;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JComboBox<String> jListaDeplegableSeleccioneSuCargo;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JPasswordField jRegistrarContrasena;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextApellido;
    private javax.swing.JTextField jTextEmail;
    private javax.swing.JTextField jTextIdentificacion;
    private javax.swing.JTextField jTextNombre;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextField jTextTelefono;
    private javax.swing.JTextField jTextUsuario;
    private javax.swing.JPanel pestanaIniciarSesion;
    private javax.swing.JPanel pestanaRegistroClientes;
    private javax.swing.JTabbedPane registroClientes;
    // End of variables declaration//GEN-END:variables
}
